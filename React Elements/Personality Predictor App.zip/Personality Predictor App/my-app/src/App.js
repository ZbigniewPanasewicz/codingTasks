//  Nationality predictor app
import React, { useState, useEffect, useRef } from 'react';

function App() {
  const [name, setName] = useState('');
  const [nationality, setNationality] = useState(null);
  const inputRef = useRef();

  useEffect(() => {
    inputRef.current.focus();
  }, []);

  const fetchNationality = async () => {
    try {
      // Making an API call to the nationalize.io service
      const response = await fetch(`https://api.nationalize.io?name=${name}`);
      const data = await response.json();
      if (data.country && data.country.length > 0) {
        setNationality(data.country[0]);
      } else {
        setNationality(null);
      }
    } catch (error) {
      // Logging any errors that occur during the fetch
      console.error('Error fetching nationality:', error);
    }
  };

  // Rendering the UI of the app
  return (
    <div className="App">
      <h1>Person Nationality Predictor</h1>
      <input
        type="text"
        placeholder="Enter a name"
        ref={inputRef}
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <button onClick={fetchNationality}>Predict Nationality</button>
      {nationality && (
        <div>
          <h2>Results:</h2>
          <p>
            Name: <strong>{name}</strong>
          </p>
          <p>
            Country: <strong>{nationality.country_id}</strong>
          </p>
          <p>
            Probability: <strong>{(nationality.probability * 100).toFixed(2)}%</strong>
          </p>
        </div>
      )}
    </div>
  );
}

export default App;