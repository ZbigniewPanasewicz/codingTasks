// Baner Component 
import React from "react";

function Baner({ logoUrl, banerUrl }) {
  return (
    <header className="header">
      

      <div className='popcorn-box'>
        <div className='popcorn-box-fordiv'>
          <table className='popcorn-box-inside'>
            <tr>
              <td><img src={banerUrl} alt="Popcorn" className="logo2" /></td>  {/* Image: Popcorn bucket */}
              <td>
                <h4>The Netflix you love for just £4.99.</h4>
                <p>Get the Standard with adverts plan.</p>
                <p className='Popcorn-link'><a href=''>Learn More {'>'}</a></p>
              </td>
            </tr>
          </table>
        </div>
      </div>
    </header>
  );
}

export default Baner;
