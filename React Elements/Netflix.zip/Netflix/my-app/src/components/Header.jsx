// Header Component
import React from "react";

function Header({ logoUrl }) {
  return (
    <header className="header">
      <div className="header-container" style={{ position: 'relative' }}>
        <div className='logo'><img src={logoUrl} alt="Netflix Logo" className="logo" /></div>
        <div className='push'><button className='netflix-sign-in-button'>Sign In</button></div>
      </div>
    </header>
  );
}
export default Header;