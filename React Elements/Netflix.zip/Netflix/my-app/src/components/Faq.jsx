import React from "react";

 {/* FAQ content */}
function Faq() {
  return (
    <hgroup className='FAQ'>
      <h3 className="Big-headline">Frequently Asked Questions</h3>

     
      <div className='FAQ'>
        <button className="accordion">What is Netflix?</button>
        <div className="panel">
          <p>Netflix is a streaming service that offers a wide variety of award-winning TV programmes, films, anime, documentaries, and more on thousands of internet-connected devices. You can watch as...</p>
        </div>

<button className="accordion">How much does Netflix cost?</button>
<div className="panel">
  <p>Watch Netflix on your smartphone, tablet, smart TV, laptop or streaming device,
  </p>
</div>

<button className="accordion">Where can I watch</button>
<div className="panel">
  <p>Watch anywhere, anytime. Sign in with your Netflix account </p>
</div>

<button className="accordion">How do I cancel?</button>
<div className="panel">
  <p>Lorem ipsum...</p>
</div>

<button className="accordion">What can I watch on Netflix?</button>
<div className="panel">
  <p>Lorem ipsum...</p>
</div>

<button className="accordion">Is Netflix good for children?</button>
<div className="panel">
  <p>Lorem ipsum...</p>
</div>

</div>

<div className='Newsleter-form'>
<div className='Hform'>
          Ready to watch? Enter your email to create or restart your membership.
        </div>
        <div className="form-container">
          <input type="email" placeholder="Email address" required />
          <button type="submit">Get started {'>'}</button>
        </div>

    
</div>

</hgroup>

  );
}

export default Faq;