// Main Component 
import React from "react";

function Main() {
  return (
    <main className="Main-content">
      {/* Main header with headline and form */}
      <header className="App-header">
        <h1 className="Big-headline">Unlimited films, TV programmes and more</h1>
        <p>Watch anywhere. Cancel at any time.</p>

        {/* Form for starting membership */}
        <div className='Hform'>
          Ready to watch? Enter your email to create or restart your membership.
        </div>
        <div className="form-container">
          <input type="email" placeholder="Email address" required />
          <button type="submit">Get started {'>'}</button>
        </div>
      </header>
    </main>
  );
}

export default Main;