import React from "react";

 {/* Footer content */}
function Footer() {
  return (
    <footer className='Footer'>
<table className='Table-footer'><tr>
  <td colspan="4">Questions? Call <a className='Footer-link' href=''>0808 196 5391</a></td></tr>
  <tr><td>
  <a className='Footer-link' href=''>FAQ</a></td>
  <td><a className='Footer-link' href=''>Help Centre</a></td>
  <td><a className='Footer-link' href=''>Account</a></td>
  <td><a className='Footer-link' href=''>Media Centre</a></td>
  </tr>
  
  <tr><td>
  <a className='Footer-link' href=''>Investor Relations</a></td>
  <td><a className='Footer-link' href=''>Jobs</a></td>
  <td><a className='Footer-link' href=''>Netflix Shop</a></td>
  <td><a className='Footer-link' href=''>Redeem gift cards</a></td>
  </tr>

  <tr><td>
  <a className='Footer-link' href=''>Buy gift cards</a></td>
  <td><a className='Footer-link' href=''>Ways to Watch</a></td>
  <td><a className='Footer-link' href=''>Terms of Use</a></td>
  <td><a className='Footer-link' href=''>Privacy</a></td>
  </tr>

  <tr><td>
  <a className='Footer-link' href=''>Cookie Preferences</a></td>
  <td><a className='Footer-link' href=''>Corporate Information</a></td>
  <td><a className='Footer-link' href=''>Contact Us</a></td>
  <td><a className='Footer-link' href=''>Speed Test</a></td>
  </tr>

  <tr><td>
  <a className='Footer-link' href=''>Legal Guarantee</a></td>
  <td><a className='Footer-link' href=''>Legal Notices</a></td>
  <td><a className='Footer-link' href=''>Only on Netflix</a></td>
  <td><a className='Footer-link' href=''>Advert choices</a></td>
  </tr>

  <tr>
  <td colspan="4">
  <select multiple className="multi-select">
  <option value="option1">English</option></select>
  </td></tr>

  <tr>
  <td colspan="4">Netfix United Kingdom
  </td></tr>

  </table>
  <div className='App-link'>Page proudly cloned from <a href="https://www.netflix.com/gb/">Netflix</a> </div>
</footer>
  );
}

export default Footer;