// Adverts Component 
import React from "react";
import tvnews2 from '../netflix-tv2.jpg'; 
import tvnews3 from '../netflix-tv3.jpg';
import tvnews4 from '../netflix-tv4.jpg';

function Adverts({ logoUrl, tvnewsUrl }) {
  return ( 
<hgroup className='Adverts'>
        <table>
          <tbody>
            <tr>
              <td className='td-center'>
                <h3 className="Big-headline">Enjoy on your TV</h3>
                <p>Watch on smart TVs, PlayStation, Xbox, Chromecast, Apple TV, Blu-ray players and more.</p>
              </td>
              <td>
              <img src={tvnewsUrl} alt="Netflix news" className="tvnews" />  {/* Image: Popcorn bucket */}
              </td>
            </tr></tbody>
        </table>
            <hr className='hr-space' />
          
            <table>
          <tbody>
            <tr>
              <td>
                <img src={tvnews2} alt="Netflix news" />
              </td>
              <td className='td-center'>
                <h3 className="Big-headline">Watch everywhere</h3>
                <p>Stream unlimited films and TV programmes on your phone, tablet, laptop and TV.</p>
              </td>
            </tr></tbody>
        </table>
        <hr className='hr-space' />

        <table>
          <tbody>
            <tr>
              <td className='td-center'>
                <h3 className="Big-headline">Create profiles for children</h3>
                <p>Send children on adventures with their favourite characters in a space made just for them – free with your membership.</p>
              </td>
              <td>
                <img src={tvnews3} alt="Netflix news" />
              </td>
            </tr></tbody>
        </table>
            <hr className='hr-space' />

<table>
          <tbody>
            <tr>
              <td>
                <img src={tvnews4} alt="Netflix news" />
              </td>
              <td className='td-center'>
                <h3 className="Big-headline">Download your programmes to watch offline</h3>
                <p>Watch on a plane, train or submarine...</p>
              </td>
            </tr></tbody>
        </table>
        <hr className='hr-space' />



</hgroup>
              
  );
}

export default Adverts;