import logo from './netflix.png';
import Header from './components/Header';
import Main from './components/Main';
import popcorn from './popcorn-box.png';
import tvnews from './netflix-tv.jpg';
import tvnews2 from './netflix-tv2.jpg';
import tvnews3 from './netflix-tv3.jpg';
import tvnews4 from './netflix-tv4.jpg';
import './App.css';


// This function toggles the accordion panels
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.display === "block") {
      panel.style.display = "none";
    } else {
      panel.style.display = "block";
    }
  });
}

// Main App component
function App() {
  return (
    <div className="App">
      <div className="App-background">
      {/* Header component with logo and sign-in button */}
      <Header logoUrl={logo} />

      {/* Main header with headline and form */}
      <div className="App-header">
        <h1 className="Big-headline">Unlimited films, TV programmes and more</h1>
        <p>Watch anywhere. Cancel at any time.</p>

        {/* Form for starting membership */}
        <div className='Hform'>
          Ready to watch? Enter your email to create or restart your membership.
        </div>
        <div className="form-container">
          <input type="email" placeholder="Email address" required />
          <button type="submit">Get started {'>'}</button>
        </div>
        </div>
        <div className="App-header-two">
        </div>
        {/* Spacer for layout */}
        <div className="Spacer"></div>

        {/* Popcorn box section */}
        <div className='popcorn-box'>
          <div className='popcorn-box-fordiv'>
            <table className='popcorn-box-inside'>
              <tr>
                <td><img src={popcorn} alt="Netflix popcorn" /></td>
                <td>
                  <h4>The Netflix you love for just £4.99.</h4>
                  <p>Get the Standard with adverts plan.</p>
                  <p className='Popcorn-link'><a href=''>Learn More &gt;</a></p>
                </td>
              </tr>
            </table>
          </div>
        </div>
      </div>

      {/* Adverts section with tables and images */}

      <hgroup className='Adverts'>
        <table>
          <tbody>
            <tr>
              <td className='td-center'>
                <h3 className="Big-headline">Enjoy on your TV</h3>
                <p>Watch on smart TVs, PlayStation, Xbox, Chromecast, Apple TV, Blu-ray players and more.</p>
              </td>
              <td>
                <img src={tvnews} alt="Netflix news" />
              </td>
            </tr></tbody>
        </table>
            <hr className='hr-space' />
          
            <table>
          <tbody>
            <tr>
              <td>
                <img src={tvnews2} alt="Netflix news" />
              </td>
              <td className='td-center'>
                <h3 className="Big-headline">Watch everywhere</h3>
                <p>Stream unlimited films and TV programmes on your phone, tablet, laptop and TV.</p>
              </td>
            </tr></tbody>
        </table>
        <hr className='hr-space' />

        <table>
          <tbody>
            <tr>
              <td className='td-center'>
                <h3 className="Big-headline">Create profiles for children</h3>
                <p>Send children on adventures with their favourite characters in a space made just for them – free with your membership.</p>
              </td>
              <td>
                <img src={tvnews3} alt="Netflix news" />
              </td>
            </tr></tbody>
        </table>
            <hr className='hr-space' />

<table>
          <tbody>
            <tr>
              <td>
                <img src={tvnews4} alt="Netflix news" />
              </td>
              <td className='td-center'>
                <h3 className="Big-headline">Download your programmes to watch offline</h3>
                <p>Watch on a plane, train or submarine...</p>
              </td>
            </tr></tbody>
        </table>
        <hr className='hr-space' />


<div><h3 className="Big-headline">Frequently Asked Questions</h3>


{/* FAQ section */}
<div className='FAQ'>
<button class="accordion">What is Netflix?</button>
<div class="panel">
  <p>Netflix is a streaming service that offers a wide variety of award-winning TV programmes, films, anime, documentaries and more on thousands of internet-connected devices.
You can watch as m</p>
</div>

<button class="accordion">How much does Netflix cost?</button>
<div class="panel">
  <p>Watch Netflix on your smartphone, tablet, smart TV, laptop or streaming device,
  </p>
</div>

<button class="accordion">Where can I watch</button>
<div class="panel">
  <p>Watch anywhere, anytime. Sign in with your Netflix account </p>
</div>

<button class="accordion">How do I cancel?</button>
<div class="panel">
  <p>Lorem ipsum...</p>
</div>

<button class="accordion">What can I watch on Netflix?</button>
<div class="panel">
  <p>Lorem ipsum...</p>
</div>

<button class="accordion">Is Netflix good for children?</button>
<div class="panel">
  <p>Lorem ipsum...</p>
</div>

</div>

<div className='Newsleter-form'>
<div className='Hform'>
          Ready to watch? Enter your email to create or restart your membership.
        </div>
        <div className="form-container">
          <input type="email" placeholder="Email address" required />
          <button type="submit">Get started {'>'}</button>
        </div>

    
</div>
</div>
<hr className='hr-space' />

 </hgroup>


{/* Footer */}
 <footer className='Footer'>
<table className='Table-footer'><tr>
  <td colspan="4">Questions? Call <a className='Footer-link' href=''>0808 196 5391</a></td></tr>
  <tr><td>
  <a className='Footer-link' href=''>FAQ</a></td>
  <td><a className='Footer-link' href=''>Help Centre</a></td>
  <td><a className='Footer-link' href=''>Account</a></td>
  <td><a className='Footer-link' href=''>Media Centre</a></td>
  </tr>
  
  <tr><td>
  <a className='Footer-link' href=''>Investor Relations</a></td>
  <td><a className='Footer-link' href=''>Jobs</a></td>
  <td><a className='Footer-link' href=''>Netflix Shop</a></td>
  <td><a className='Footer-link' href=''>Redeem gift cards</a></td>
  </tr>

  <tr><td>
  <a className='Footer-link' href=''>Buy gift cards</a></td>
  <td><a className='Footer-link' href=''>Ways to Watch</a></td>
  <td><a className='Footer-link' href=''>Terms of Use</a></td>
  <td><a className='Footer-link' href=''>Privacy</a></td>
  </tr>

  <tr><td>
  <a className='Footer-link' href=''>Cookie Preferences</a></td>
  <td><a className='Footer-link' href=''>Corporate Information</a></td>
  <td><a className='Footer-link' href=''>Contact Us</a></td>
  <td><a className='Footer-link' href=''>Speed Test</a></td>
  </tr>

  <tr><td>
  <a className='Footer-link' href=''>Legal Guarantee</a></td>
  <td><a className='Footer-link' href=''>Legal Notices</a></td>
  <td><a className='Footer-link' href=''>Only on Netflix</a></td>
  <td><a className='Footer-link' href=''>Advert choices</a></td>
  </tr>

  <tr>
  <td colspan="4">
  <select multiple className="multi-select">
  <option value="option1">English</option></select>
  </td></tr>

  <tr>
  <td colspan="4">Netfix United Kingdom
  </td></tr>

  </table>
  <div className='Spacer'><a href="https://www.netflix.com/gb/">Netflix</a> </div>
</footer>

    </div>
  );
}

export default App;
