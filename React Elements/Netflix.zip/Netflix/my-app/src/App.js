import logo from './netflix.png';
import Header from './components/Header';
import Main from './components/Main';
import Baner from './components/Baner';
import Faq from './components/Faq'; 
import banerImage from './popcorn-box.png'; 
import tvnews from './netflix-tv.jpg';

import './App.css';
import Adverts from './components/Adverts';
import Footer from './components/Footer';


// This function toggles the accordion panels
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.display === "block") {
      panel.style.display = "none";
    } else {
      panel.style.display = "block";
    }
  });
}

// Main App component
function App() {
  return (
    <div className="App">
      <div className="App-background">
      {/* Header component with logo and sign-in button */}
      <Header logoUrl={logo} />

      {/* Main header with headline and form */}
      <Main />


        {/* Spacer for layout */}
        <div className="Spacer"></div>

        {/* Popcorn box section */}
        <Baner banerUrl={banerImage} />
       
       </div>

      {/* Adverts section with tables and images */}

    <Adverts  tvnewsUrl={tvnews} />  


    <Faq />

  {/* Spacer for layout */}
    <hr className='hr-space' />


  {/* Footer */}
  <Footer />

    </div>
  );
}

export default App;
