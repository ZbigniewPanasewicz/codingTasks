import React, { useState } from 'react';
// Add Interest component
export default function AddInterest({ balance, onBalanceUpdate }) {
  const [interestAdded, setInterestAdded] = useState(false); // Track if interest has been added

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!interestAdded) {
      // Fixed interest rate (8% annually)
      const fixedInterestRate = 8;
      // Calculate the interest amount
      const interestAmount = (balance * fixedInterestRate) / 100;
      // Call the onBalanceUpdate function passed as a prop with the interest amount
      onBalanceUpdate(balance + interestAmount);
      // Set interestAdded to true to prevent further use
      setInterestAdded(true);
    }
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <button type='submit' disabled={interestAdded}>Add Interest (8%)</button>
      </form>
      {interestAdded && <p>Interest has already been added.</p>}
    </div>
  );
}
