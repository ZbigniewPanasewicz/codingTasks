import React, { useState } from 'react';

export default function MoneyOutput({ balance, onBalanceUpdate }) {
  const [moneyAmount, setMoneyAmount] = useState('');
  const [error, setError] = useState(''); // State to hold the error message

  const handleInputChange = (event) => {
    setError(''); // Clear any existing error messages
    setMoneyAmount(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const amountToDeduct = parseFloat(moneyAmount);
    if (amountToDeduct > 0) {
      if (amountToDeduct <= balance) {
        onBalanceUpdate(-amountToDeduct);
        setMoneyAmount('');
      } else {
        // Set an error message if the amount is greater than the balance
        setError('Cannot withdraw more than the available balance. Please enter a different amount.');
      }
    }
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <label htmlFor='moneyOutput'>Withdraw Amount: </label>
        <input
          type='text'
          id='moneyOutput'
          placeholder='Enter amount to withdraw'
          value={moneyAmount}
          onChange={handleInputChange}
        />
        <button type='submit'>Withdraw Money</button>
        {error && <p className="error">{error}</p>} {/* Display the error message if there is one */}
      </form>
    </div>
  );
}
