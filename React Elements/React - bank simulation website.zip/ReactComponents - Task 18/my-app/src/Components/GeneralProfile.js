// GeneralProfile component
import React from 'react';
import UserProfile from './UserProfile'; // Import the UserProfile component
import logo from '../Images/Zbigniew_Panasewicz.jpg'; // Import the profile picture

const user = {
  name: 'Zbigniew',
  surname: 'Panasewicz',
  dateOfBirth: '1990-01-01',
  address: 'SL1, Slough',
  country: 'United Kingdom',
  email: 'z.panasewicz@gmail.com',
  telephone: '07846938469',
  company: 'YMAA OrientSport',
  profilePicture: logo,
};

const GeneralProfile = () => {
  return (
    <div>
      
      <UserProfile user={user} /> {/* Render the UserProfile component */}
    </div>
  );
};

export default GeneralProfile;
