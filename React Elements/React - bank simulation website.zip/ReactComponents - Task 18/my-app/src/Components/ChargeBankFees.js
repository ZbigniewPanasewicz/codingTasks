import React, { useState } from 'react';
// Charge Bank fees component
export default function ChargeBankFees({ balance, onBalanceUpdate }) {
  const [feeCharged, setFeeCharged] = useState(false); // Track if fee has been charged

  const fixedFeeAmount = 17; // Fixed fee amount

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!feeCharged) {
      // Calculate the new balance after deducting the fixed fee
      const newBalance = balance - fixedFeeAmount; // This should be a subtraction
      // Call the onBalanceUpdate function passed as a prop with the new balance
      onBalanceUpdate(-fixedFeeAmount); // Pass the negative fee amount to subtract
      // Set feeCharged to true to prevent further charges
      setFeeCharged(true);
    }
  };
  

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <button type='submit' disabled={feeCharged}>Charge Bank Fee (£17)</button>
      </form>
      {feeCharged && <p>Fee has already been charged for this session.</p>}
    </div>
  );
}
