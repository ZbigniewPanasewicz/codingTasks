// UserProfile component
import React from 'react';

const UserProfile = ({ user }) => {
  return (
    <div className="UserProfile">
      <img src={user.profilePicture} className="Profile-logo" alt="profile" />
      <h1>{user.name} {user.surname}</h1>
      <p><strong>Date of Birth:</strong> {user.dateOfBirth}</p>
      <p><strong>Address:</strong> {user.address}</p>
      <p><strong>Country:</strong> {user.country}</p>
      <p><strong>Email:</strong> {user.email}</p>
      <p><strong>Telephone:</strong> {user.telephone}</p>
      <p><strong>Company:</strong> {user.company}</p>
    </div>
  );
};

export default UserProfile;
