import React, { useState } from 'react';

export default function MoneyInput({ balance, onBalanceUpdate }) {
  const [moneyAmount, setMoneyAmount] = useState(''); // Setup moneyAmount state

  const handleInputChange = (event) => {
    const inputValue = event.target.value;
    // Validate input
    if (/^\d+(\.\d{0,2})?$/.test(inputValue)) {
      setMoneyAmount(inputValue);
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    // Check if moneyAmount is not empty and greater than zero
    if (moneyAmount && parseFloat(moneyAmount) > 0) {
      // Call the onBalanceUpdate function passed as a prop
      onBalanceUpdate(parseFloat(moneyAmount));
      // Reset the moneyAmount for new entry
      setMoneyAmount('');
    }
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <label htmlFor='moneyInput'>Enter Amount: </label>
        <input
          type='text'
          id='moneyInput'
          placeholder='Enter amount here'
          value={moneyAmount}
          onChange={handleInputChange}
        />
        <button type='submit'>Add Money</button>
      </form>
    </div>
  );
}
