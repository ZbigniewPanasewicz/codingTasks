import React, { useState } from 'react';
import MoneyInput from './Components/MoneyInput.js';
import MoneyOutput from './Components/MoneyOutput.js';
import GeneralProfile from './Components/GeneralProfile.js';
import AddInterest from './Components/AddInterest.js';
import ChargeBankFees from './Components/ChargeBankFees.js';
import ymaaLogo from './Images/YMAA_Bank.jpeg';
import './App.css';

function App() {
  // setup balance state with £3000
  const [balance, setBalance] = useState(3000);

  // Create a function to update the balance
  const handleBalanceUpdate = (amount) => {
    // Deduct the Bank fee
    setBalance((prevBalance) => prevBalance + amount); 
  };
  

  return (
    <div className="App">
      <table>
        <tr>
          <td className='UserProfile'>
            <GeneralProfile />
            <br />
            {/* Display the balance here */}
            <h3>Your balance:<br/>£{balance.toFixed(2)}</h3>
          </td>
          {/* Display Bank options */}
          <td>{/* Bank logo */}
            <img src={ymaaLogo} alt="YMAA Bank Logo" className="App-logo" />
            <table className='BankOption'><tr><th>YOUR ACCOUNT OPTION:</th></tr>
            <tr><td><MoneyInput balance={balance} onBalanceUpdate={handleBalanceUpdate} /><hr></hr></td></tr>
            <tr><td><MoneyOutput balance={balance} onBalanceUpdate={handleBalanceUpdate} /><hr></hr></td></tr>
            <tr><td><AddInterest balance={balance} onBalanceUpdate={handleBalanceUpdate} /><hr></hr></td></tr>
            <tr><td><ChargeBankFees balance={balance} onBalanceUpdate={handleBalanceUpdate} /> 
            </td></tr></table>
          </td>
        </tr>
      </table>
    </div>
  );
}

export default App;
