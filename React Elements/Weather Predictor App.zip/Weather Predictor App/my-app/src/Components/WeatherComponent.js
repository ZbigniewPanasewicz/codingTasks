// WeatherComponent
import React, { useState } from 'react';

function WeatherComponent({ apiKey, city }) {
  const [weather, setWeather] = useState(null);
  const [error, setError] = useState('');

  const fetchWeather = async () => {
    const encodedCity = encodeURIComponent(city);
    const url = `https://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${encodedCity}&aqi=no`;

    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      setWeather(data);
      setError('');
    } catch (error) {
      console.error('Error fetching weather:', error);
      setError('Failed to fetch weather data. Please check the city name or try again later.');
    }
  };

  return (
    <div>
      <button onClick={fetchWeather}>Get Weather</button>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      {weather && (
        <div>
          <h2>Weather in {weather.location?.name}</h2>
          <p>Temperature: {weather.current?.temp_c}°C</p>
          <p>Weather: {weather.current?.condition?.text}</p>
          <p>Wind Speed: {weather.current?.wind_kph} kph</p>
        </div>
      )}
    </div>
  );
}

export default WeatherComponent;
