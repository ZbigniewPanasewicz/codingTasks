// App.js
import React, { useState } from 'react';
import WeatherComponent from './Components/WeatherComponent'; // Import the new component
import './App.css';

function App() {
  const [city, setCity] = useState('');
  const apiKey = 'cf455e710787439483b125513242805'; // API key

  return (
    <div className="weather-box">
      <h1>Weather App</h1>
      <input
        type="text"
        placeholder="Enter city name"
        value={city}
        onChange={(e) => setCity(e.target.value)}
      />
      <WeatherComponent apiKey={apiKey} city={city} />
    </div>
  );
}

export default App;
